<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="DataTables/datatables.min.css">
	<script src="jquery/jquery-3.6.0.min.js"></script>
	<script type="text/javascript" src="DataTables/datatables.js"></script>
    <title>Document</title>
</head>
<body>
    
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "company";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} else {
	// echo "Successfully connected";
}


$req = "SELECT id,Name, Description,Age,Nickname,Employee,Acion FROM features";
    $result = $conn->query($req);

    if ($result->num_rows > 0) {
    echo'<table id="table_id" class="display">';
        
    echo "<thead>
   
        <th>id</th>
        <th>Name</th>
        <th>Description</th>
        <th>Age</th>
        <th>Nickname</th>
        <th>Employee</th>
        <th>Acion</th>
        </thead>";

        while($row = $result->fetch_assoc()) {
        echo"<tr><td>".$row["id"]."</td><td>".$row["Name"]."</td><td>".$row["Description"].
        "</td><td>".$row["Age"]."</td><td>".$row["Nickname"]."</td><td>".$row["Employee"].
        "</td><td>".$row["Action"]."</td></tr>";

}

   echo'</table>';
} 
  $conn->close();

?>

<script>
		$(document).ready(function () {
		    $('#table_id').DataTable();
		} );
	</script>

</body>
</html>